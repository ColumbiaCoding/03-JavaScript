// Fill in the body of each function with the code required

var add = function(num1, num2) {};

var subtract = function(num1, num2) {};

var multiply = function(num1, num2) {};

var divide = function(num1, num2) {};
