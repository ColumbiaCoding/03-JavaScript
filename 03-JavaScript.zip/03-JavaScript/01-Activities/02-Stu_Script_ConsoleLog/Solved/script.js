// Open up the console to see this log
console.log("Your external JavaScript file is linked 🎉");
